import { motion, AnimatePresence } from 'framer-motion'
import { countries } from '../data/countries'

export default function PassportChip({ visited, visible }) {
  return (
    <div className={`fixed bottom-5 right-5 z-[300] transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}`}>
      <div className="flex items-center gap-2.5 rounded-full border border-paper/10 bg-ink/55 backdrop-blur-md pl-3 pr-4 py-2.5">
        <svg viewBox="0 0 24 24" width="15" height="15" className="text-gold">
          <path fill="currentColor" d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 2c1.2 0 2.3.3 3.3.8-.5 1-1.3 2.5-1.3 4.2 0 2.3 1.4 4.1 2.6 5-1.2 1-2.7 1.6-4.4 1.8V17h-.4v-1.2c-1.7-.2-3.2-.8-4.4-1.8 1.2-.9 2.6-2.7 2.6-5 0-1.7-.8-3.2-1.3-4.2A8 8 0 0 1 12 4z" />
        </svg>
        <div className="flex gap-1.5 text-sm">
          <AnimatePresence>
            {countries.filter(c => visited.has(c.id)).map((c) => (
              <motion.span
                key={c.id}
                initial={{ scale: 0, rotate: -20, opacity: 0 }}
                animate={{ scale: 1, rotate: 0, opacity: 1 }}
                transition={{ type: 'spring', stiffness: 300, damping: 16 }}
              >
                {c.stampIcon}
              </motion.span>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </div>
  )
}
