import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { countries } from '../data/countries'

export default function Loader({ onDone }) {
  const [pct, setPct] = useState(0)
  const [lit, setLit] = useState(0)
  const [done, setDone] = useState(false)

  useEffect(() => {
    let raf
    const start = performance.now()
    const durationMs = 2400
    const tick = (now) => {
      const t = Math.min(1, (now - start) / durationMs)
      const eased = 1 - Math.pow(1 - t, 2)
      const p = Math.floor(eased * 100)
      setPct(p)
      setLit(Math.min(countries.length, Math.floor(eased * (countries.length + 0.4))))
      if (t < 1) {
        raf = requestAnimationFrame(tick)
      } else {
        setTimeout(() => setDone(true), 380)
        setTimeout(() => onDone?.(), 900)
      }
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [onDone])

  const nodeCount = countries.length + 1 // +1 for departure

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          className="fixed inset-0 z-[500] flex flex-col items-center justify-center gap-8"
          style={{ background: 'radial-gradient(circle at 50% 42%, #14183a 0%, #07080D 70%)' }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.7 }}
        >
          <div className="relative w-[180px] h-[180px]">
            <svg viewBox="0 0 200 200" className="w-full h-full animate-[spin-slow_9s_linear_infinite]">
              <circle cx="100" cy="100" r="78" fill="none" stroke="rgba(201,162,75,0.22)" strokeWidth="1" />
              <ellipse cx="100" cy="100" rx="78" ry="30" fill="none" stroke="rgba(201,162,75,0.32)" strokeWidth="1" />
              <ellipse cx="100" cy="100" rx="78" ry="30" fill="none" stroke="rgba(201,162,75,0.22)" strokeWidth="1" transform="rotate(60 100 100)" />
              <ellipse cx="100" cy="100" rx="78" ry="30" fill="none" stroke="rgba(201,162,75,0.22)" strokeWidth="1" transform="rotate(120 100 100)" />
            </svg>
            {/* route dots that light up as loader progresses */}
            {Array.from({ length: nodeCount }).map((_, i) => {
              const angle = (i / nodeCount) * Math.PI * 2 - Math.PI / 2
              const r = 78
              const cx = 100 + r * Math.cos(angle)
              const cy = 100 + r * Math.sin(angle)
              const active = i <= lit
              return (
                <div
                  key={i}
                  className="absolute rounded-full transition-all duration-500"
                  style={{
                    left: cx, top: cy, width: active ? 8 : 4, height: active ? 8 : 4,
                    transform: 'translate(-50%,-50%)',
                    background: active ? '#C9A24B' : 'rgba(246,242,233,0.25)',
                    boxShadow: active ? '0 0 12px 3px rgba(201,162,75,0.7)' : 'none',
                  }}
                />
              )
            })}
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="w-2.5 h-2.5 rounded-full bg-gold" />
            </div>
          </div>

          <div className="flex flex-col items-center gap-3">
            <p className="font-mono text-[10px] tracking-[0.24em] uppercase text-paper/55">Preparing your itinerary</p>
            <div className="w-[220px] h-px bg-paper/15">
              <div className="h-full bg-gold transition-all duration-150" style={{ width: pct + '%' }} />
            </div>
            <p className="font-mono text-[11px] text-paper/45">{pct}%</p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
