import { useEffect, useRef, useState } from 'react'

// Tries to load /src/assets/images/{photo}. If it 404s (none dropped in yet),
// falls back to the layered gradient using the country's theme tokens, so
// the deck looks intentional either way. Drop a licensed photo in at the
// path named on `theme.photo` and it's picked up automatically — no code
// changes needed.
export default function CinematicBG({ photo, theme, landmarkNode, parallaxRef }) {
  const [photoUrl, setPhotoUrl] = useState(null)

  useEffect(() => {
    let cancelled = false
    // Vite glob import of anything dropped into assets/images by the user.
    const modules = import.meta.glob('/src/assets/images/*', { eager: true, query: '?url', import: 'default' })
    const match = Object.entries(modules).find(([path]) => path.endsWith('/' + photo))
    if (match && !cancelled) setPhotoUrl(match[1])
    return () => { cancelled = true }
  }, [photo])

  const gradient = `linear-gradient(180deg, ${theme.from} 0%, ${theme.via} 50%, ${theme.to} 100%)`

  return (
    <div className="absolute inset-0 overflow-hidden">
      <div
        ref={parallaxRef}
        className="absolute inset-[-6%] will-change-transform"
        style={{
          backgroundImage: photoUrl ? `url(${photoUrl})` : gradient,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          filter: photoUrl ? 'brightness(0.72) saturate(1.05)' : 'none',
        }}
      />
      {/* dark cinematic overlay so type stays legible over any photo */}
      <div
        className="absolute inset-0"
        style={{
          background: `linear-gradient(180deg, rgba(7,8,13,0.15) 0%, rgba(7,8,13,0.05) 35%, rgba(7,8,13,0.55) 100%)`,
        }}
      />
      {landmarkNode}
    </div>
  )
}
