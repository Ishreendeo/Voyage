import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import gsap from 'gsap'
import ScrollTrigger from 'gsap/ScrollTrigger'
import CinematicBG from './CinematicBG'
import ParticleField from './ParticleField'
import InfoCard from './InfoCard'
import { landmarkFor } from './Landmarks'
import useTitleParallax from '../lib/useTitleParallax'
import { countries } from '../data/countries'

gsap.registerPlugin(ScrollTrigger)

const SWAY_DURATIONS = [11, 13, 9, 14, 10]

export default function CountryScene({ country, onOpenCard, onEnter, reduceMotion }) {
  const sectionRef = useRef(null)
  const titleRef = useRef(null)
  const parallaxRef = useRef(null)
  const landmarkRef = useRef(null)
  const Landmark = landmarkFor[country.id]
  const { x: titleX, y: titleY } = useTitleParallax(reduceMotion)

  const countryIndex = countries.findIndex((c) => c.id === country.id)
  const swayDuration = SWAY_DURATIONS[countryIndex % SWAY_DURATIONS.length]

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(parallaxRef.current,
        { scale: 1.12, yPercent: -4 },
        {
          scale: 1.0, yPercent: 4, ease: 'none',
          scrollTrigger: { trigger: sectionRef.current, start: 'top bottom', end: 'bottom top', scrub: 0.6 },
        })

      gsap.fromTo(landmarkRef.current,
        { y: 40, opacity: 0.2 },
        {
          y: 0, opacity: 1, ease: 'none',
          scrollTrigger: { trigger: sectionRef.current, start: 'top bottom', end: 'top center', scrub: 0.6 },
        })

      const letters = titleRef.current.querySelectorAll('span')
      gsap.fromTo(letters,
        { yPercent: 120, opacity: 0 },
        {
          yPercent: 0, opacity: 1, duration: 0.9, stagger: 0.025, ease: 'power3.out',
          scrollTrigger: { trigger: titleRef.current, start: 'top 88%' },
        })

      ScrollTrigger.create({
        trigger: sectionRef.current,
        start: 'top center',
        end: 'bottom center',
        onEnter: () => onEnter?.(country.id),
        onEnterBack: () => onEnter?.(country.id),
      })
    }, sectionRef)
    return () => ctx.revert()
  }, [country.id, onEnter])

  const letters = country.name.split('')

  return (
    <section ref={sectionRef} data-scene={country.id} className="relative min-h-screen flex items-center justify-center overflow-hidden px-6 py-32">
      <CinematicBG photo={country.photo} theme={country.theme} parallaxRef={parallaxRef} landmarkNode={
        <div ref={landmarkRef} className="absolute inset-x-0 bottom-0 h-[46%] will-change-transform">
          <div
            className={reduceMotion ? 'w-full h-full' : 'landmark-sway w-full h-full'}
            style={reduceMotion ? undefined : {
              '--sway-duration': `${swayDuration}s`,
              '--sway-delay': `${countryIndex * 0.6}s`,
            }}
          >
            <Landmark className="w-full h-full" />
          </div>
        </div>
      } />
      {!reduceMotion && <ParticleField type={country.particles} reduceMotion={reduceMotion} />}

      <div className="relative z-[2] max-w-[880px] text-center">
        <p className="font-mono text-[10.5px] tracking-[0.28em] uppercase text-gold mb-4">Now landing</p>
        <motion.h2
          ref={titleRef}
          style={{ x: titleX, y: titleY }}
          className="font-display font-medium leading-[0.94] text-[clamp(52px,10vw,120px)] overflow-hidden flex justify-center flex-wrap"
        >
          {letters.map((l, i) => (
            <span key={i} className="inline-block will-change-transform">{l === ' ' ? '\u00A0' : l}</span>
          ))}
        </motion.h2>
        <p className="font-display italic font-light text-[clamp(15px,2vw,20px)] mt-4 opacity-85 max-w-[540px] mx-auto">
          {country.tagline}
        </p>

        <div className="flex flex-wrap gap-3 justify-center mt-12">
          {country.cards.map((c, i) => (
            <InfoCard
              key={c.title}
              icon={c.icon}
              title={c.title}
              label={c.label}
              accent={country.theme.accent}
              onOpen={() => onOpenCard(c)}
              floatIndex={i}
              reduceMotion={reduceMotion}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
