import { useRef, useEffect } from 'react'
import gsap from 'gsap'
import ScrollTrigger from 'gsap/ScrollTrigger'
import CloudLayer from './CloudLayer'
import CinematicPlane from './CinematicPlane'

gsap.registerPlugin(ScrollTrigger)

export default function CloudBridge({ label, index }) {
  const rootRef = useRef(null)
  const farRef = useRef(null)
  const midRef = useRef(null)
  const nearRef = useRef(null)
  const planeWrapRef = useRef(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: rootRef.current,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 0.6,
        },
      })
      tl.fromTo(farRef.current, { xPercent: -8, yPercent: 4 }, { xPercent: 8, yPercent: -4, ease: 'none' }, 0)
        .fromTo(midRef.current, { xPercent: 6, yPercent: -2 }, { xPercent: -10, yPercent: 3, ease: 'none' }, 0)
        .fromTo(nearRef.current, { xPercent: -4, opacity: 0.2 }, { xPercent: 4, opacity: 1, ease: 'none' }, 0)
        .to(nearRef.current, { opacity: 0.15, ease: 'none' }, 0.75)
        .fromTo(planeWrapRef.current,
          { xPercent: -70, yPercent: 25, opacity: 0, rotate: -4 },
          { xPercent: 70, yPercent: -20, opacity: 1, rotate: 6, ease: 'none' }, 0.05)
        .to(planeWrapRef.current, { opacity: 0, ease: 'none' }, 0.8)
    }, rootRef)
    return () => ctx.revert()
  }, [])

  return (
    <section ref={rootRef} className="relative h-[70vh] overflow-hidden bg-gradient-to-b from-[#1a2140] via-[#7d93b8] to-[#e9eff4]">
      <div ref={farRef} className="absolute inset-0 will-change-transform z-0">
        <CloudLayer depth="far" className="w-full h-full" />
      </div>
      <div ref={midRef} className="absolute inset-0 will-change-transform z-10">
        <CloudLayer depth="mid" className="w-full h-full" />
      </div>
      <div ref={nearRef} className="absolute inset-0 will-change-transform z-20">
        <CloudLayer depth="near" className="w-full h-full" />
      </div>
      <div ref={planeWrapRef} className="absolute top-[28%] left-1/2 -translate-x-1/2 will-change-transform z-30">
        <CinematicPlane size={150} tilt={8} />
      </div>
      <p className="absolute bottom-10 left-1/2 -translate-x-1/2 font-mono text-[10px] tracking-[0.24em] uppercase text-[#1b2444]/80 text-center px-6 z-40">
        {label}
      </p>
    </section>
  )
}
