import { useMemo } from 'react'

const CONFIG = {
  petals: { count: 26, size: [7, 13], dur: [10, 19] },
  lanterns: { count: 10, size: [16, 26], dur: [7, 11] },
  dust: { count: 40, size: [2, 4], dur: [10, 20] },
  mist: { count: 14, size: [120, 260], dur: [14, 24] },
  confetti: { count: 44, size: [5, 10], dur: [7, 13] },
}

const CONFETTI_COLORS = ['#FFD23F', '#04A777', '#F0653B', '#F6F2E9', '#0B3D91']

function rand(min, max) { return Math.random() * (max - min) + min }

export default function ParticleField({ type, reduceMotion }) {
  const particles = useMemo(() => {
    if (reduceMotion) return []
    const cfg = CONFIG[type]
    if (!cfg) return []
    return Array.from({ length: cfg.count }, (_, i) => ({
      id: i,
      left: rand(0, 100),
      top: type === 'lanterns' ? rand(55, 92) : rand(-10, 40),
      size: rand(...cfg.size),
      duration: rand(...cfg.dur),
      delay: -rand(0, cfg.dur[1]),
      drift: rand(-70, 70),
      color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
      rot: rand(-15, 15),
    }))
  }, [type, reduceMotion])

  if (!particles.length) return null

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-[1]">
      {particles.map((p) => {
        if (type === 'petals') {
          return (
            <div key={p.id} style={{
              position: 'absolute', left: p.left + '%', top: p.top + '%',
              width: p.size, height: p.size, background: '#E6A2BB',
              borderRadius: '0 100% 0 100%', opacity: 0.8,
              animation: `petal-fall ${p.duration}s linear infinite`,
              animationDelay: p.delay + 's', '--drift': p.drift + 'px',
            }} />
          )
        }
        if (type === 'lanterns') {
          return (
            <div key={p.id} style={{
              position: 'absolute', left: p.left + '%', top: p.top + '%',
              width: p.size, height: p.size * 1.3, borderRadius: '40% 40% 46% 46%',
              background: 'linear-gradient(180deg,#FFD873,#E8792E)',
              boxShadow: '0 0 18px 4px rgba(255,180,60,0.55)',
              animation: `float-y ${p.duration}s ease-in-out infinite, glow-pulse ${p.duration * 0.4}s ease-in-out infinite`,
              animationDelay: p.delay + 's', '--r': p.rot + 'deg',
            }} />
          )
        }
        if (type === 'dust') {
          return (
            <div key={p.id} style={{
              position: 'absolute', left: '-5%', top: p.top + '%',
              width: p.size, height: p.size, borderRadius: '50%',
              background: '#F2D08A', opacity: 0.45,
              animation: `drift-x ${p.duration}s linear infinite`,
              animationDelay: p.delay + 's',
            }} />
          )
        }
        if (type === 'mist') {
          return (
            <div key={p.id} style={{
              position: 'absolute', left: p.left + '%', top: p.top + '%',
              width: p.size, height: p.size * 0.4, borderRadius: '50%',
              background: 'radial-gradient(closest-side, rgba(255,255,255,0.22), transparent)',
              filter: 'blur(2px)',
              animation: `drift-x ${p.duration}s linear infinite`,
              animationDelay: p.delay + 's',
            }} />
          )
        }
        // confetti
        return (
          <div key={p.id} style={{
            position: 'absolute', left: p.left + '%', top: p.top + '%',
            width: p.size, height: p.size * 1.8, background: p.color,
            borderRadius: p.id % 2 ? '50%' : '2px',
            animation: `confetti-fall ${p.duration}s linear infinite`,
            animationDelay: p.delay + 's',
          }} />
        )
      })}
    </div>
  )
}
