import { motion, AnimatePresence } from 'framer-motion'

export default function Modal({ card, onClose }) {
  return (
    <AnimatePresence>
      {card && (
        <motion.div
          className="fixed inset-0 z-[400] flex items-center justify-center p-6"
          style={{ background: 'rgba(5,7,15,0.72)', backdropFilter: 'blur(10px)' }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            className="relative w-full max-w-[420px] rounded-2xl border p-8"
            style={{ background: '#12162a', borderColor: 'rgba(201,162,75,0.28)' }}
            initial={{ opacity: 0, y: 20, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 14, scale: 0.96 }}
            transition={{ type: 'spring', stiffness: 260, damping: 24 }}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              data-cursor="hover"
              onClick={onClose}
              aria-label="Close"
              className="absolute top-4 right-4 text-paper/50 hover:text-paper text-base"
            >
              ✕
            </button>
            <span className="block text-3xl mb-3">{card.icon}</span>
            <p className="font-mono text-[9.5px] tracking-[0.2em] uppercase text-gold mb-2">{card.label}</p>
            <h3 className="font-display font-medium text-2xl mb-3">{card.title}</h3>
            <p className="text-[13.5px] leading-relaxed text-paper/65">{card.body}</p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
