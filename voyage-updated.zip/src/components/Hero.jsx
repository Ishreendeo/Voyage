import { useEffect, useMemo, useRef } from 'react'
import { motion } from 'framer-motion'
import gsap from 'gsap'
import CinematicPlane from './CinematicPlane'
import { countries } from '../data/countries'
import useTitleParallax from '../lib/useTitleParallax'

function useStars(count) {
  return useMemo(() => Array.from({ length: count }, () => ({
    left: Math.random() * 100,
    top: Math.random() * 55,
    size: Math.random() * 1.6 + 1,
    dur: Math.random() * 3 + 2,
    delay: -Math.random() * 4,
  })), [count])
}

export default function Hero({ reduceMotion }) {
  const stars = useStars(reduceMotion ? 25 : 70)
  const planeRef = useRef(null)
  const { x: titleX, y: titleY } = useTitleParallax(reduceMotion, { xFactor: 10, yFactor: 6 })

  useEffect(() => {
    if (reduceMotion) return
    const ctx = gsap.context(() => {
      gsap.fromTo(planeRef.current,
        { x: '-30vw', y: 40, rotate: 2, opacity: 0 },
        { x: '55vw', y: -160, rotate: -14, opacity: 1, duration: 3.2, ease: 'power2.inOut', delay: 1.1 })
    })
    return () => ctx.revert()
  }, [reduceMotion])

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden px-6 py-32 bg-gradient-to-b from-[#05060d] via-[#0b0f22] to-[#131a36]">
      {/* stars */}
      <div className="absolute inset-0">
        {stars.map((s, i) => (
          <div key={i} className="absolute rounded-full bg-paper" style={{
            left: s.left + '%', top: s.top + '%', width: s.size, height: s.size,
            animation: `twinkle ${s.dur}s ease-in-out infinite`, animationDelay: s.delay + 's',
          }} />
        ))}
      </div>

      {/* runway + skyline */}
      <svg className="absolute bottom-0 left-0 w-full h-[24vh] opacity-90" viewBox="0 0 1200 220" preserveAspectRatio="none">
        <path d="M0 220 L0 150 L50 150 L50 110 L95 110 L95 160 L150 160 L150 90 L168 90 L168 160 L220 160 L220 125 L265 125 L265 170 L320 170 L320 70 L342 70 L342 170 L410 170 L410 135 L465 135 L465 100 L498 100 L498 170 L565 170 L565 80 L588 80 L588 170 L662 170 L662 145 L728 145 L728 95 L760 95 L760 145 L828 145 L828 170 L895 170 L895 115 L928 115 L928 170 L1005 170 L1005 135 L1060 135 L1060 160 L1115 160 L1115 100 L1148 100 L1148 160 L1200 160 L1200 220 Z" fill="#0a0e1c" />
      </svg>
      {/* runway lights */}
      <div className="absolute bottom-0 left-0 right-0 h-[6vh] flex justify-center gap-8 items-end pb-2">
        {Array.from({ length: 14 }).map((_, i) => (
          <span key={i} className="w-1.5 h-1.5 rounded-full bg-gold" style={{
            animation: `glow-pulse ${1.6 + (i % 4) * 0.2}s ease-in-out infinite`, animationDelay: (i * 0.12) + 's',
          }} />
        ))}
      </div>

      <div ref={planeRef} className="absolute" style={{ willChange: 'transform' }}>
        <CinematicPlane size={110} tilt={-6} />
      </div>

      <div className="relative z-[2] flex flex-col items-center text-center">
        {/* boarding pass / departure board */}
        <motion.div
          initial={{ y: -16, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.15, ease: [0.16, 0.8, 0.24, 1] }}
          className="w-[min(460px,88vw)] rounded-xl border border-gold/25 bg-paper/[0.03] backdrop-blur-md overflow-hidden mb-12"
        >
          <div className="flex items-center justify-between px-5 py-3 border-b border-dashed border-gold/25">
            <span className="font-mono text-[9px] tracking-[0.16em] uppercase text-paper/50">Voyage Airlines · Gate 01</span>
            <span className="font-mono text-[9px] text-gold">ON TIME</span>
          </div>
          <div className="px-5 py-4 flex flex-col gap-1.5">
            {countries.map((c) => (
              <div key={c.id} className="flex justify-between font-mono text-[10.5px] tracking-[0.06em]">
                <span className="text-paper/70">{c.name.toUpperCase()}</span>
                <span className="text-paper/35">BOARDING</span>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.h1
          style={{ x: titleX, y: titleY }}
          className="font-display font-medium leading-[0.9] text-[clamp(64px,12vw,148px)]"
        >
          Voyage
        </motion.h1>
        <p className="font-display italic font-light text-gold text-[clamp(15px,2.2vw,21px)] mt-2">
          Around the World in One Scroll
        </p>
        <p className="text-[14.5px] leading-relaxed text-paper/50 mt-6 max-w-[480px]">
          No booking. No baggage. Five destinations on one continuous flight —
          scroll to take off, and let the passport fill itself in.
        </p>

        <div className="mt-16 flex flex-col items-center gap-3">
          <span className="font-mono text-[9.5px] tracking-[0.26em] uppercase text-paper/35">Scroll to board</span>
          <div className="relative w-px h-11 bg-paper/15 overflow-hidden">
            <span className="absolute -top-2 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-gold" style={{ animation: 'cue-fall 1.9s ease-in-out infinite' }} />
          </div>
        </div>
      </div>

      <style>{`
        @keyframes cue-fall { 0% { transform: translate(-50%,-10px); opacity: 0; } 30% { opacity: 1; } 100% { transform: translate(-50%,44px); opacity: 0; } }
      `}</style>
    </section>
  )
}
