import { motion } from 'framer-motion'

export const PLANE_PATH =
  'M58 34.5v-4.8L36 15.4V8.6c0-2.4-1.8-4.3-4-4.3s-4 1.9-4 4.3v6.8L6 29.7v4.8l22-6.4v14.6l-7 5v3.4l9-2.7 9 2.7v-3.4l-7-5V28.1z'

export default function CinematicPlane({ className = '', tilt = 0, size = 120, contrail = true }) {
  return (
    <motion.div
      className={`relative ${className}`}
      style={{ width: size, height: size }}
      animate={{ rotate: tilt }}
      transition={{ duration: 1.2, ease: [0.16, 0.8, 0.24, 1] }}
    >
      {contrail && (
        <div
          className="absolute top-1/2 right-full h-[3px] w-[220%] origin-right"
          style={{
            background: 'linear-gradient(90deg, transparent, rgba(246,242,233,0.55) 40%, rgba(246,242,233,0.85))',
            transform: 'translateY(-50%)',
            filter: 'blur(1px)',
          }}
        />
      )}
      <svg viewBox="0 0 64 64" width={size} height={size} style={{ filter: 'drop-shadow(0 14px 22px rgba(0,0,0,0.35))' }}>
        <path fill="#F6F2E9" d={PLANE_PATH} />
      </svg>
    </motion.div>
  )
}
