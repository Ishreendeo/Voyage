import { useEffect, useRef, useState } from 'react'
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion'
import useMousePosition from '../lib/useMousePosition'
import { PLANE_PATH } from './CinematicPlane'

const SIZE = 28

export default function CustomCursor() {
  const [enabled, setEnabled] = useState(false)
  const [hovering, setHovering] = useState(false)
  const mouse = useMousePosition()

  const prevRef = useRef({ x: 0, y: 0 })
  const hasPrevRef = useRef(false)

  const rawX = useMotionValue(0)
  const rawY = useMotionValue(0)
  const x = useSpring(rawX, { stiffness: 420, damping: 32, mass: 0.45 })
  const y = useSpring(rawY, { stiffness: 420, damping: 32, mass: 0.45 })
  const heading = useSpring(0, { stiffness: 140, damping: 22, mass: 0.35 })
  const hoverTilt = useSpring(0, { stiffness: 220, damping: 18 })

  const passportScale = useSpring(1, { stiffness: 120, damping: 22 })
  const hoverScale = useSpring(1, { stiffness: 260, damping: 20 })

  const scale = useTransform(
    [passportScale, hoverScale],
    ([passport, hover]) => passport * hover,
  )

  const rotation = useTransform([heading, hoverTilt], ([h, t]) => h + t)

  const glowOpacity = useSpring(0, { stiffness: 100, damping: 24 })
  const filter = useTransform(glowOpacity, (o) =>
    `drop-shadow(0 0 ${6 + o * 22}px rgba(201,162,75,${0.15 + o * 0.55})) drop-shadow(0 4px 10px rgba(0,0,0,0.35))`,
  )

  useEffect(() => {
    const coarse = window.matchMedia('(pointer: coarse)').matches
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    setEnabled(!coarse && !reduced)
  }, [])

  useEffect(() => {
    if (!enabled) return

    rawX.set(mouse.clientX)
    rawY.set(mouse.clientY)

    if (hasPrevRef.current) {
      const dx = mouse.clientX - prevRef.current.x
      const dy = mouse.clientY - prevRef.current.y
      if (Math.hypot(dx, dy) > 1.5) {
        heading.set(Math.atan2(dy, dx) * (180 / Math.PI))
      }
    }

    prevRef.current = { x: mouse.clientX, y: mouse.clientY }
    hasPrevRef.current = true
  }, [enabled, mouse.clientX, mouse.clientY, rawX, rawY, heading])

  useEffect(() => {
    if (!enabled) return undefined

    const onOver = (e) => {
      if (e.target.closest?.('[data-cursor="hover"]')) setHovering(true)
    }

    const onOut = (e) => {
      const hoverEl = e.target.closest?.('[data-cursor="hover"]')
      if (!hoverEl) return
      const to = e.relatedTarget
      if (to && hoverEl.contains(to)) return
      setHovering(false)
    }

    const onPassport = (e) => {
      const progress = Math.max(0, Math.min(1, e.detail?.progress ?? 0))
      passportScale.set(1 + progress * 0.6)
      glowOpacity.set(progress)
    }

    window.addEventListener('mouseover', onOver)
    window.addEventListener('mouseout', onOut)
    window.addEventListener('voyage:near-passport', onPassport)

    return () => {
      window.removeEventListener('mouseover', onOver)
      window.removeEventListener('mouseout', onOut)
      window.removeEventListener('voyage:near-passport', onPassport)
    }
  }, [enabled, passportScale, glowOpacity])

  useEffect(() => {
    hoverScale.set(hovering ? 1.18 : 1)
    hoverTilt.set(hovering ? 12 : 0)
  }, [hovering, hoverScale, hoverTilt])

  if (!enabled) return null

  return (
    <motion.div
      className="fixed top-0 left-0 z-[600] pointer-events-none"
      style={{
        x,
        y,
        translateX: '-50%',
        translateY: '-50%',
        rotate: rotation,
        scale,
        filter,
      }}
    >
      <svg
        viewBox="0 0 64 64"
        width={SIZE}
        height={SIZE}
        aria-hidden="true"
        style={{ overflow: 'visible' }}
      >
        <path fill="#F6F2E9" d={PLANE_PATH} />
      </svg>
    </motion.div>
  )
}
