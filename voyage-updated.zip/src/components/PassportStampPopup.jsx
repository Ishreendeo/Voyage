import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { countries } from '../data/countries'

// A single stamp "thunk" pop-up, fired once per destination as it's reached.
// Styled to match the ink-stamp language already used in the passport
// collage (Ending.jsx) — same maroon ring, same font-mono uppercase city
// label — just staged as a momentary overlay instead of a static collage
// piece, so the whole journey reads as one consistent passport metaphor.
const STAMP_COLOR = '#7a1f3d'
const HOLD_MS = 1700
const REDUCED_HOLD_MS = 900

export default function PassportStampPopup({ event, reduceMotion }) {
  const [visible, setVisible] = useState(false)

  const country = event ? countries.find((c) => c.id === event.id) : null

  useEffect(() => {
    if (!event) return undefined
    setVisible(true)
    const hideTimer = setTimeout(() => setVisible(false), reduceMotion ? REDUCED_HOLD_MS : HOLD_MS)
    return () => clearTimeout(hideTimer)
  }, [event, reduceMotion])

  return (
    <div className="fixed inset-0 z-[350] flex items-center justify-center pointer-events-none">
      <AnimatePresence>
        {visible && country && (
          <motion.div
            key={event.key}
            initial={reduceMotion ? { opacity: 0 } : { opacity: 0, scale: 2.4, rotate: -16 }}
            animate={
              reduceMotion
                ? { opacity: 1 }
                : { opacity: 1, scale: [2.4, 0.86, 1.06, 1], rotate: [-16, -9, -6, -8] }
            }
            exit={{ opacity: 0, scale: reduceMotion ? 1 : 0.92, transition: { duration: 0.85, ease: [0.16, 0.8, 0.24, 1] } }}
            transition={
              reduceMotion
                ? { duration: 0.4, ease: 'easeOut' }
                : { duration: 1.5, ease: [0.16, 0.8, 0.24, 1], times: [0, 0.55, 0.8, 1] }
            }
            className="relative flex flex-col items-center justify-center gap-1.5 w-[176px] h-[176px] rounded-full border-[3px] font-mono uppercase select-none backdrop-blur-[2px]"
            style={{
              borderColor: STAMP_COLOR,
              color: STAMP_COLOR,
              background: 'rgba(246,242,233,0.16)',
              boxShadow: `0 24px 60px rgba(0,0,0,0.45), inset 0 0 0 1px rgba(122,31,61,0.3)`,
            }}
          >
            <span className="text-[38px] leading-none">{country.stampIcon}</span>
            <span className="text-[13px] tracking-[0.22em]">{country.stampCity}</span>
            <span className="text-[8px] tracking-[0.32em] opacity-70">Arrived</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
