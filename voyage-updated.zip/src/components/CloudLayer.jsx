// A hand-built layered cloud bank (soft overlapping ellipses with blur +
// varying opacity) rather than the flat circles from v1. Multiple copies at
// different scales/speeds/opacities create the sense of flying *through*
// something with depth, not past a sticker.
function CloudPuff({ x, y, s, o }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
      <ellipse cx="0" cy="0" rx="90" ry="40" fill="#fff" />
      <ellipse cx="55" cy="-10" rx="60" ry="34" fill="#fff" />
      <ellipse cx="-55" cy="-6" rx="65" ry="36" fill="#fff" />
      <ellipse cx="10" cy="18" rx="100" ry="30" fill="#fff" />
      <ellipse cx="-30" cy="24" rx="60" ry="22" fill="#fff" />
    </g>
  )
}

export default function CloudLayer({ depth = 'near', className = '' }) {
  const sets = {
    far: [
      { x: 120, y: 90, s: 1.6, o: 0.35 },
      { x: 520, y: 60, s: 2.1, o: 0.3 },
      { x: 900, y: 120, s: 1.8, o: 0.32 },
    ],
    mid: [
      { x: 60, y: 220, s: 2.6, o: 0.55 },
      { x: 480, y: 260, s: 3.1, o: 0.6 },
      { x: 860, y: 200, s: 2.4, o: 0.5 },
    ],
    near: [
      { x: -60, y: 340, s: 4.2, o: 0.92 },
      { x: 420, y: 380, s: 4.8, o: 0.96 },
      { x: 900, y: 330, s: 4.0, o: 0.9 },
      { x: 1200, y: 400, s: 4.6, o: 0.94 },
    ],
  }
  return (
    <svg
      className={className}
      viewBox="0 0 1200 500"
      preserveAspectRatio="xMidYMid slice"
      style={{ filter: depth === 'near' ? 'blur(1px)' : 'blur(3px)' }}
      aria-hidden="true"
    >
      {sets[depth].map((c, i) => <CloudPuff key={i} {...c} />)}
    </svg>
  )
}
