// Layered, large-scale SVG landmark illustrations. These stand in as the
// "signature art" layer that sits in front of the photo/gradient background
// for every country scene, rendered bigger and with more depth than v1.

export function JapanLandmark({ className }) {
  return (
    <svg className={className} viewBox="0 0 800 420" preserveAspectRatio="xMidYMax meet" aria-hidden="true">
      {/* Fuji */}
      <path d="M120 360 L360 90 L430 200 L500 90 L680 360 Z" fill="#4A2E44" opacity="0.35" />
      <path d="M360 90 L400 155 L320 155 Z" fill="#fff" opacity="0.55" />
      <path d="M500 90 L520 130 L470 130 Z" fill="#fff" opacity="0.4" />
      {/* mid ridge */}
      <path d="M0 360 L150 260 L260 360 Z" fill="#3A1E2E" opacity="0.3" />
      <path d="M540 360 L660 250 L800 360 Z" fill="#3A1E2E" opacity="0.28" />
      {/* torii */}
      <g transform="translate(310,255)">
        <rect x="0" y="0" width="16" height="130" fill="#8C3B5A" />
        <rect x="164" y="0" width="16" height="130" fill="#8C3B5A" />
        <rect x="-24" y="-10" width="228" height="22" rx="3" fill="#8C3B5A" />
        <rect x="-8" y="24" width="196" height="14" rx="3" fill="#8C3B5A" />
      </g>
    </svg>
  )
}

export function IndiaLandmark({ className }) {
  return (
    <svg className={className} viewBox="0 0 800 420" preserveAspectRatio="xMidYMax meet" aria-hidden="true">
      <rect x="300" y="230" width="200" height="150" fill="#F7EAD2" opacity="0.9" />
      <path d="M300 230 Q400 110 500 230 Z" fill="#F7EAD2" opacity="0.9" />
      <circle cx="400" cy="140" r="16" fill="#F7EAD2" opacity="0.9" />
      <rect x="260" y="270" width="26" height="110" fill="#F7EAD2" opacity="0.75" />
      <rect x="514" y="270" width="26" height="110" fill="#F7EAD2" opacity="0.75" />
      <circle cx="273" cy="256" r="11" fill="#F7EAD2" opacity="0.75" />
      <circle cx="527" cy="256" r="11" fill="#F7EAD2" opacity="0.75" />
      <rect x="190" y="310" width="20" height="70" fill="#F7EAD2" opacity="0.55" />
      <rect x="590" y="310" width="20" height="70" fill="#F7EAD2" opacity="0.55" />
      <path d="M320 380 L320 260 Q400 220 480 260 L480 380 Z" fill="#3B0E52" opacity="0.18" />
    </svg>
  )
}

export function EgyptLandmark({ className }) {
  return (
    <svg className={className} viewBox="0 0 800 420" preserveAspectRatio="xMidYMax meet" aria-hidden="true">
      <path d="M120 380 L300 150 L480 380 Z" fill="#1B2635" opacity="0.75" />
      <path d="M300 150 L332 205 L240 380 L300 380 Z" fill="#12202f" opacity="0.5" />
      <path d="M400 380 L540 210 L680 380 Z" fill="#1B2635" opacity="0.55" />
      <path d="M0 380 L110 280 L190 380 Z" fill="#1B2635" opacity="0.4" />
      <circle cx="640" cy="120" r="46" fill="#F2D08A" opacity="0.35" />
    </svg>
  )
}

export function ItalyLandmark({ className }) {
  return (
    <svg className={className} viewBox="0 0 800 340" preserveAspectRatio="xMidYMax meet" aria-hidden="true">
      <rect x="40" y="140" width="120" height="150" fill="#E7D3AE" opacity="0.7" />
      <rect x="170" y="90" width="110" height="200" fill="#D9BE8C" opacity="0.75" />
      <rect x="290" y="150" width="100" height="140" fill="#E7D3AE" opacity="0.65" />
      <path d="M390 150 L432 90 L474 150 Z" fill="#B4895F" opacity="0.65" />
      <rect x="500" y="120" width="120" height="170" fill="#D9BE8C" opacity="0.7" />
      <rect x="630" y="170" width="110" height="120" fill="#E7D3AE" opacity="0.65" />
      <g opacity="0.35" fill="#0A2E32">
        <rect x="70" y="165" width="18" height="24" />
        <rect x="110" y="165" width="18" height="24" />
        <rect x="200" y="130" width="18" height="24" />
        <rect x="240" y="130" width="18" height="24" />
      </g>
    </svg>
  )
}

export function BrazilLandmark({ className }) {
  return (
    <svg className={className} viewBox="0 0 800 420" preserveAspectRatio="xMidYMax meet" aria-hidden="true">
      <path d="M0 380 L180 220 L320 380 Z" fill="#062043" opacity="0.5" />
      <path d="M280 380 L460 180 L640 380 Z" fill="#062043" opacity="0.38" />
      <g transform="translate(380,140)">
        <rect x="-6" y="0" width="12" height="120" fill="#F6F2E9" opacity="0.85" />
        <rect x="-64" y="26" width="128" height="12" rx="3" fill="#F6F2E9" opacity="0.85" />
        <rect x="-5" y="-28" width="10" height="32" fill="#F6F2E9" opacity="0.85" />
      </g>
    </svg>
  )
}

export const landmarkFor = {
  japan: JapanLandmark,
  india: IndiaLandmark,
  egypt: EgyptLandmark,
  italy: ItalyLandmark,
  brazil: BrazilLandmark,
}
