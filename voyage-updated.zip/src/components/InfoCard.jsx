import { useRef, useState } from 'react'
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion'

export default function InfoCard({ icon, title, label, accent, onOpen, floatIndex = 0, reduceMotion = false }) {
  const ref = useRef(null)
  const [hovered, setHovered] = useState(false)
  const x = useMotionValue(0.5)
  const y = useMotionValue(0.5)
  const rotateX = useSpring(useTransform(y, [0, 1], [10, -10]), { stiffness: 200, damping: 20 })
  const rotateY = useSpring(useTransform(x, [0, 1], [-10, 10]), { stiffness: 200, damping: 20 })
  const glowX = useTransform(x, [0, 1], ['0%', '100%'])
  const glowY = useTransform(y, [0, 1], ['0%', '100%'])

  const floatDuration = 4.5 + floatIndex * 0.35

  function handleMove(e) {
    const rect = ref.current.getBoundingClientRect()
    x.set((e.clientX - rect.left) / rect.width)
    y.set((e.clientY - rect.top) / rect.height)
  }
  function handleLeave() {
    x.set(0.5)
    y.set(0.5)
  }

  return (
    <motion.button
      ref={ref}
      data-cursor="hover"
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      onHoverStart={() => setHovered(true)}
      onHoverEnd={() => setHovered(false)}
      onClick={onOpen}
      style={{ rotateX, rotateY, transformPerspective: 700 }}
      animate={{
        y: hovered ? -8 : reduceMotion ? 0 : [0, -2.5, 0],
      }}
      transition={{
        opacity: { duration: 0.55, ease: [0.16, 0.8, 0.24, 1] },
        y: hovered
          ? { type: 'spring', stiffness: 300, damping: 22 }
          : { duration: floatDuration, repeat: reduceMotion ? 0 : Infinity, ease: 'easeInOut' },
      }}
      whileTap={{ scale: 0.97 }}
      className="info-card relative w-[180px] min-h-[168px] rounded-2xl border p-5 text-left overflow-hidden backdrop-blur-xl"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true, amount: 0.4 }}
    >
      <div
        className="absolute inset-0 opacity-90"
        style={{ background: 'rgba(255,255,255,0.055)', borderColor: 'rgba(255,255,255,0.14)' }}
      />
      <motion.div
        className="pointer-events-none absolute -inset-10 opacity-0 hover:opacity-100"
        style={{
          background: `radial-gradient(180px circle at ${glowX} ${glowY}, ${accent}33, transparent 70%)`,
        }}
      />
      <div className="relative flex flex-col h-full">
        <span className="text-2xl">{icon}</span>
        <h3 className="font-display font-medium text-[17px] mt-3.5">{title}</h3>
        <span
          className="font-mono text-[8.5px] tracking-[0.16em] uppercase mt-auto pt-2.5 opacity-60"
          style={{ color: accent }}
        >
          {label}
        </span>
      </div>
      <div
        className="absolute inset-0 rounded-2xl border pointer-events-none"
        style={{ borderColor: 'rgba(255,255,255,0.14)' }}
      />
    </motion.button>
  )
}
