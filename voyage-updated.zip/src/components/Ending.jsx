import { useEffect, useMemo, useRef } from 'react'
import { motion } from 'framer-motion'
import gsap from 'gsap'
import ScrollTrigger from 'gsap/ScrollTrigger'
import { countries } from '../data/countries'
import useTitleParallax from '../lib/useTitleParallax'

gsap.registerPlugin(ScrollTrigger)

export default function Ending({ visited, reduceMotion }) {
  const sectionRef = useRef(null)
  const { x: titleX, y: titleY } = useTitleParallax(reduceMotion)

  const stars = useMemo(() => Array.from({ length: reduceMotion ? 40 : 110 }, () => ({
    left: Math.random() * 100, top: Math.random() * 100,
    size: Math.random() * 1.6 + 1, dur: Math.random() * 4 + 2, delay: -Math.random() * 4,
  })), [reduceMotion])

  const nodes = useMemo(() => countries.map((c, i) => ({
    id: c.id,
    x: 12 + (i * 76) / (countries.length - 1),
    y: 30 + Math.sin(i * 1.3) * 14,
  })), [])

  const path = nodes.map((n, i) => `${i === 0 ? 'M' : 'L'} ${n.x} ${n.y}`).join(' ')

  useEffect(() => {
    if (reduceMotion) return undefined

    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: sectionRef.current,
        start: 'top 70%',
        end: 'bottom bottom',
        scrub: true,
        onUpdate: (self) => {
          window.dispatchEvent(
            new CustomEvent('voyage:near-passport', { detail: { progress: self.progress } }),
          )
        },
      })
    }, sectionRef)

    return () => {
      ctx.revert()
      window.dispatchEvent(new CustomEvent('voyage:near-passport', { detail: { progress: 0 } }))
    }
  }, [reduceMotion])

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden px-6 py-32"
      style={{ background: 'radial-gradient(ellipse at 50% 18%, #171c3d 0%, #07080D 70%)' }}
    >
      <div className="absolute inset-0">
        {stars.map((s, i) => (
          <div key={i} className="absolute rounded-full bg-paper" style={{
            left: s.left + '%', top: s.top + '%', width: s.size, height: s.size,
            animation: `twinkle ${s.dur}s ease-in-out infinite`, animationDelay: s.delay + 's',
          }} />
        ))}
        <div className="absolute top-[9%] right-[13%] w-20 h-20 rounded-full" style={{
          background: 'radial-gradient(circle at 35% 35%, #fdf6e3, #d8cba3 75%)',
          boxShadow: '0 0 60px rgba(253,246,227,0.25)',
        }} />
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 60" preserveAspectRatio="none">
          <motion.path
            d={path} fill="none" stroke="rgba(201,162,75,0.55)" strokeWidth="0.15"
            initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} viewport={{ once: true }}
            transition={{ duration: 2 }}
          />
          {nodes.map((n) => (
            <circle key={n.id} cx={n.x} cy={n.y} r={visited.has(n.id) ? 0.7 : 0.35}
              fill={visited.has(n.id) ? '#C9A24B' : 'rgba(246,242,233,0.3)'} />
          ))}
        </svg>
      </div>

      <div className="relative z-[2] flex flex-col items-center text-center">
        <p className="font-mono text-[10.5px] tracking-[0.28em] uppercase text-gold mb-4">Journey complete</p>
        <motion.h2
          style={{ x: titleX, y: titleY }}
          className="font-display font-medium text-[clamp(40px,7vw,72px)]"
        >
          Your Passport
        </motion.h2>

        <motion.div
          initial={{ rotateY: -35, opacity: 0 }}
          whileInView={{ rotateY: 0, opacity: 1 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 1, ease: [0.16, 0.8, 0.24, 1] }}
          style={{ transformPerspective: 1400 }}
          className="mt-11 w-[min(520px,90vw)] min-h-[250px] flex rounded-xl overflow-hidden border border-gold/25 shadow-[0_30px_80px_rgba(0,0,0,0.5)]"
        >
          <div className="flex-[0_0_38%] flex flex-col items-center justify-center gap-2 border-r border-dashed border-gold/25 font-mono text-[11px] tracking-[0.16em] uppercase text-gold" style={{ background: 'linear-gradient(160deg,#1B3A5C,#07080D)' }}>
            <svg viewBox="0 0 24 24" width="28" height="28"><path fill="currentColor" d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 2c1.2 0 2.3.3 3.3.8-.5 1-1.3 2.5-1.3 4.2 0 2.3 1.4 4.1 2.6 5-1.2 1-2.7 1.6-4.4 1.8V17h-.4v-1.2c-1.7-.2-3.2-.8-4.4-1.8 1.2-.9 2.6-2.7 2.6-5 0-1.7-.8-3.2-1.3-4.2A8 8 0 0 1 12 4z" /></svg>
            <p>Passport</p>
            <p className="font-mono text-[8px] text-paper/40 normal-case tracking-normal">Voyage travel document</p>
          </div>
          <div className="flex-1 flex flex-wrap content-start gap-3.5 p-6" style={{ background: 'repeating-linear-gradient(0deg, #F6F2E9, #F6F2E9 24px, #ece7db 25px)' }}>
            {countries.filter(c => visited.has(c.id)).map((c, i) => (
              <motion.div
                key={c.id}
                initial={{ scale: 0, rotate: 0, opacity: 0 }}
                whileInView={{ scale: 1, rotate: (i % 2 ? -10 : 8), opacity: 0.85 }}
                viewport={{ once: true }}
                transition={{ type: 'spring', stiffness: 140, damping: 11, delay: i * 0.18 }}
                className="w-[70px] h-[70px] rounded-full border-[1.5px] flex flex-col items-center justify-center gap-0.5 font-mono text-[9.5px]"
                style={{ borderColor: '#7a1f3d', color: '#7a1f3d' }}
              >
                <span className="text-[15px]">{c.stampIcon}</span>
                <span>{c.stampCity}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <p className="font-display italic font-light text-[clamp(16px,2.3vw,21px)] mt-10 leading-relaxed text-paper/80">
          "The world is full of stories.<br />This was only the beginning."
        </p>

        <button
          data-cursor="hover"
          onClick={() => window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' })}
          className="mt-9 px-8 py-3.5 rounded-full border border-gold text-gold font-mono text-[10.5px] tracking-[0.2em] uppercase hover:bg-gold hover:text-ink transition-colors duration-300"
        >
          Fly Again
        </button>
      </div>
    </section>
  )
}
