import { countries } from '../data/countries'

export default function FlightRoute({ progress, activeScene, visible }) {
  const stops = ['dep', ...countries.map(c => c.id)]
  return (
    <div
      className={`fixed top-0 left-0 right-0 z-[300] pt-5 px-4 sm:px-10 pointer-events-none transition-opacity duration-700 ${visible ? 'opacity-100' : 'opacity-0'}`}
    >
      <div className="max-w-[640px] mx-auto rounded-full border border-paper/10 bg-ink/55 backdrop-blur-md px-5 pt-3 pb-2.5">
        <div className="flex items-center gap-2.5">
          <span className="w-1.5 h-1.5 rounded-full bg-gold shrink-0" />
          <div className="relative flex-1 h-px bg-paper/15">
            <div
              className="absolute left-0 top-0 h-full bg-gold transition-[width] duration-150"
              style={{ width: `${progress * 100}%` }}
            />
            <div
              className="absolute top-1/2 -translate-y-1/2 text-gold transition-[left] duration-150"
              style={{ left: `${progress * 100}%`, transform: 'translate(-50%,-50%) rotate(90deg)' }}
            >
              <svg viewBox="0 0 24 24" width="13" height="13"><path fill="currentColor" d="M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2.5 1.8V22l3.5-1 3.5 1v-1.2L12 19v-5.5l9 2.5z" /></svg>
            </div>
          </div>
          <span className="w-1.5 h-1.5 rounded-full bg-gold shrink-0" />
        </div>
        <div className="flex justify-between mt-2 font-mono text-[9px] tracking-[0.14em] uppercase">
          {stops.map((s) => (
            <span key={s} className={`transition-colors duration-300 ${s === activeScene ? 'text-gold' : 'text-paper/30'}`}>
              {s === 'dep' ? 'DEP' : s.slice(0, 3).toUpperCase()}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
