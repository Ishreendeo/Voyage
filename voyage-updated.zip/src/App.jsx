import { useEffect, useRef, useState, useCallback } from 'react'
import gsap from 'gsap'
import ScrollTrigger from 'gsap/ScrollTrigger'
import useLenis from './lib/useLenis'
import { countries } from './data/countries'
import Loader from './components/Loader'
import Hero from './components/Hero'
import CloudBridge from './components/CloudBridge'
import CountryScene from './components/CountryScene'
import Ending from './components/Ending'
import FlightRoute from './components/FlightRoute'
import PassportChip from './components/PassportChip'
import PassportStampPopup from './components/PassportStampPopup'
import CustomCursor from './components/CustomCursor'
import Modal from './components/Modal'

gsap.registerPlugin(ScrollTrigger)

export default function App() {
  const [ready, setReady] = useState(false)
  const [progress, setProgress] = useState(0)
  const [activeScene, setActiveScene] = useState('dep')
  const [visited, setVisited] = useState(() => new Set())
  const [card, setCard] = useState(null)
  const [stampEvent, setStampEvent] = useState(null)
  const stampedRef = useRef(new Set())
  const reduceMotion = typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches

  useLenis({ enabled: ready })

  useEffect(() => {
    if (!ready) return undefined
    const st = ScrollTrigger.create({
      trigger: document.documentElement,
      start: 'top top',
      end: 'bottom bottom',
      onUpdate: (self) => setProgress(self.progress),
    })
    const refresh = () => ScrollTrigger.refresh()
    window.addEventListener('load', refresh)
    return () => { st.kill(); window.removeEventListener('load', refresh) }
  }, [ready])

  const handleEnter = useCallback((id) => {
    setActiveScene(id)
    if (!stampedRef.current.has(id)) {
      stampedRef.current.add(id)
      setStampEvent({ id, key: `${id}-${Date.now()}` })
    }
    setVisited((prev) => {
      if (prev.has(id)) return prev
      const next = new Set(prev)
      next.add(id)
      return next
    })
  }, [])

  return (
    <>
      <Loader onDone={() => setReady(true)} />
      {ready && <CustomCursor />}
      <div className="grain-overlay" />
      <FlightRoute progress={progress} activeScene={activeScene} visible={ready} />
      <PassportChip visited={visited} visible={ready} />
      <PassportStampPopup event={ready ? stampEvent : null} reduceMotion={reduceMotion} />

      <main className="relative">
        <Hero reduceMotion={reduceMotion} />

        {countries.map((country, i) => (
          <div key={country.id}>
            <CloudBridge label={country.transitLabel} index={i} />
            <CountryScene
              country={country}
              onOpenCard={setCard}
              onEnter={handleEnter}
              reduceMotion={reduceMotion}
            />
          </div>
        ))}

        <Ending visited={visited} reduceMotion={reduceMotion} />
      </main>

      <Modal card={card} onClose={() => setCard(null)} />
    </>
  )
}
