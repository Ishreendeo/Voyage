// Central content model. Each country carries its own palette, copy, cards,
// particle system, and the *name* of an optional photo to drop into
// /src/assets/images/{photo}. If that file doesn't exist, the CinematicBG
// component gracefully falls back to the layered gradient + SVG scene.

export const countries = [
  {
    id: 'japan',
    name: 'Japan',
    tagline: 'Where silence has architecture, and spring falls like snow.',
    transitLabel: 'Climbing to 34,000 ft — next stop, Japan',
    photo: 'japan.jpg',
    stampCity: 'TOKYO',
    stampIcon: '🌸',
    theme: {
      from: '#FBF3F6', via: '#E9B9CC', to: '#3A1E2E',
      ink: '#2A1622', accent: '#D88CA6', accent2: '#1B2340',
      textDark: true,
    },
    particles: 'petals',
    cards: [
      { icon: '🌸', title: 'Hanami', label: 'Tradition', body: 'From late March to April, cherry blossoms sweep the country in a pink wave from south to north. Parks fill with hanami picnics under the blooming trees — a centuries-old ritual of watching petals fall.' },
      { icon: '🍱', title: 'Kaiseki', label: 'Food', body: "A multi-course meal built around the season's freshest ingredients, plated with the precision of a small painting. Each dish arrives as its own quiet ceremony — nothing rushed, nothing wasted." },
      { icon: '⛩️', title: 'Torii Gates', label: 'Landmark', body: 'Thousands of vermilion torii gates climb the forested slopes of Mount Inari in Kyoto, forming tunnels of color that shift with the light. Each gate is a donation, inscribed with a name and a wish.' },
      { icon: '🏮', title: 'Gion Matsuri', label: 'Festival', body: "Kyoto's month-long summer festival fills the streets with towering wooden floats, hand-pulled through the old town to the sound of flutes and bells — a tradition unbroken since the 9th century." },
    ],
  },
  {
    id: 'india',
    name: 'India',
    tagline: 'A thousand languages of color, spice, and light.',
    transitLabel: 'Descending over the Thar — welcome to India',
    photo: 'india.jpg',
    stampCity: 'AGRA',
    stampIcon: '🪔',
    theme: {
      from: '#3B0E52', via: '#8A2C55', to: '#E8792E',
      ink: '#F7EAD2', accent: '#F2B33D', accent2: '#3B0E52',
      textDark: false,
    },
    particles: 'lanterns',
    cards: [
      { icon: '🪔', title: 'Diwali', label: 'Festival', body: 'Homes are lined with clay diyas and rangoli patterns to welcome prosperity for the new year. Fireworks and sweets follow, and for five nights, entire cities glow.' },
      { icon: '🍛', title: 'Thali', label: 'Food', body: "A single plate carrying an entire region's cooking — lentils, vegetables, breads, pickle, and something sweet — meant to balance six tastes in one sitting." },
      { icon: '🕌', title: 'Taj Mahal', label: 'Landmark', body: 'Built by Emperor Shah Jahan for his wife Mumtaz Mahal, this ivory-white marble mausoleum took over 20,000 artisans and 17 years to complete. It changes color with the light, from pink dawn to golden dusk.' },
      { icon: '🪁', title: 'Uttarayan', label: 'Tradition', body: 'Every January, the skies over Gujarat fill with thousands of kites during Uttarayan, as families climb rooftops to fly, dodge, and cut lines from dawn until after dark.' },
    ],
  },
  {
    id: 'egypt',
    name: 'Egypt',
    tagline: '4,500 years of sand keeping careful watch over stone.',
    transitLabel: 'Crossing the Red Sea — next stop, Egypt',
    photo: 'egypt.jpg',
    stampCity: 'GIZA',
    stampIcon: '🔺',
    theme: {
      from: '#4A2F2A', via: '#8A5A2B', to: '#D8B073',
      ink: '#1B2635', accent: '#EFDFC0', accent2: '#8A5A2B',
      textDark: false,
    },
    particles: 'dust',
    cards: [
      { icon: '🔺', title: 'Giza Pyramids', label: 'Landmark', body: 'The last standing wonder of the ancient world. The Great Pyramid was the tallest human-made structure on Earth for nearly 3,800 years, built as a tomb for Pharaoh Khufu.' },
      { icon: '🥘', title: 'Koshari', label: 'Food', body: "Egypt's unofficial national dish layers rice, lentils, and macaroni under crispy fried onions and spiced tomato sauce — humble street food eaten by everyone, everywhere." },
      { icon: '🛶', title: 'The Nile', label: 'Tradition', body: "Feluccas, Egypt's traditional wooden sailboats, still drift down the Nile as they have for millennia — the river that made the entire civilization possible in the middle of a desert." },
      { icon: '☀️', title: 'Sun Festival', label: 'Festival', body: 'Twice a year, sunlight travels 60 meters into the temple of Abu Simbel to illuminate the inner sanctuary statues — an alignment the ancient builders engineered with nothing but observation.' },
    ],
  },
  {
    id: 'italy',
    name: 'Italy',
    tagline: 'A country that turned everyday life into an art form.',
    transitLabel: 'Tracing the Adriatic — welcome to Italy',
    photo: 'italy.jpg',
    stampCity: 'VENICE',
    stampIcon: '🛶',
    theme: {
      from: '#0B2E38', via: '#0B4C5F', to: '#1E7A63',
      ink: '#0A2E32', accent: '#F1ECE1', accent2: '#0B4C5F',
      textDark: false,
    },
    particles: 'mist',
    cards: [
      { icon: '🛶', title: 'The Canals', label: 'Landmark', body: 'Built across 118 small islands linked by over 400 bridges, Venice has no roads for cars — only water, and the gondoliers who have navigated it for eight centuries.' },
      { icon: '🍝', title: 'Pasta', label: 'Food', body: "Every region claims its own shape and sauce — from Bologna's ragù to Genoa's pesto — each tied to local wheat, local hands, and a grandmother's exact ratios." },
      { icon: '🎭', title: 'Carnevale', label: 'Festival', body: 'For weeks before Lent, Venice fills with elaborate porcelain masks and cloaked figures, a tradition that let nobles and commoners mingle anonymously as equals centuries ago.' },
      { icon: '🚶', title: 'Passeggiata', label: 'Tradition', body: 'The evening stroll — dressed well, unhurried, through the piazza before dinner. Not a walk to get anywhere, but a small daily ritual of being seen and seeing others.' },
    ],
  },
  {
    id: 'brazil',
    name: 'Brazil',
    tagline: 'Rhythm as a way of life, and a city that dances until dawn.',
    transitLabel: 'Crossing the Atlantic — final stop, Brazil',
    photo: 'brazil.jpg',
    stampCity: 'RIO',
    stampIcon: '🎉',
    theme: {
      from: '#0B3D91', via: '#0A6B4E', to: '#F0653B',
      ink: '#062043', accent: '#FFD23F', accent2: '#04A777',
      textDark: false,
    },
    particles: 'confetti',
    cards: [
      { icon: '🎉', title: 'Carnaval', label: 'Festival', body: "For five days before Lent, samba schools spend a year's preparation on a single night's parade through the Sambadrome — floats, feathers, and drums loud enough to feel in your chest." },
      { icon: '🍲', title: 'Feijoada', label: 'Food', body: 'A slow-cooked black bean and pork stew, traditionally shared on Saturdays with rice, orange, and farofa — a dish said to have roots in resourcefulness turned into celebration.' },
      { icon: '🗿', title: 'Christ the Redeemer', label: 'Landmark', body: 'Standing 30 meters tall atop Corcovado mountain, arms open over Rio de Janeiro since 1931 — visible from nearly every corner of the city it watches over.' },
      { icon: '🥁', title: 'Roda de Samba', label: 'Tradition', body: "An informal circle of musicians and dancers that can start on any street corner — samba's original form, before the stage and the spotlight, still played in Rio's backyards today." },
    ],
  },
]

export const countryIds = countries.map(c => c.id)
